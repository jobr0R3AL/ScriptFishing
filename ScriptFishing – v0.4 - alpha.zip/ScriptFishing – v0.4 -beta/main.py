#!/usr/bin/env python3
#one thing: so googles gemini has helped with this so if u dont mind then aight and also i have wrote a vast majority of the code so dont rage to me
import time
import random

from biomes import BIOMES

catch_chance = 0.3
fish_types = [
    "A WHALE?!?!?!",
    "Trout!", 
    "Bass!", 
    "Rainbow Trout!", 
    "Salmon!", 
    "Pike!",
    "Catfish!",     
    "Walleye!",     
    "Goldfish?!",   
    "Sturgeon!",    
    "Carp!",         
    "Pocket Whale", 
    "Common whitefish?", 
    "Boot..."
]

# LEVEL CALCULATOR - Reads lifetime progress from the local log file
try:
    with open("fishing_log.txt", "r", encoding="utf-8") as f:
        total_catches = len(f.readlines())
except FileNotFoundError:
    total_catches = 0

player_level = 1 + (total_catches // 5)
inv = []

print("-=-=-=-= ScriptFishing! v0.4 =-=-=-=-")
print(f"LIFETIME LEVEL: {player_level} | Catches to Level Up: {5 - (total_catches % 5)}")
print("Commands: 'fish' | 'inv' | 'quit', 'biome'")

# --- THE MAIN MENU ENGINE ---
while True:
    action = input("\n[Action]: ").strip().lower() 
    if action == "quit":
        print(f"\nHauled home {len(inv)} fish this session. Tight lines!")
        break
        
    elif action == "inv":
        print("\n--- CURRENT POCKETS ---")
        if not inv:
            print("Pockets are empty! Use 'fish' to cast.")
        else:
            for item in inv:
                print(f"-> {item}")
        print("-------------------------")
        
    elif action == "fish":
        if player_level >= 100:
            zone = BIOMES["volcano"]
        elif player_level >= 35:
            zone = BIOMES["woods"]
        elif player_level >= 25:
            zone = BIOMES["sea"]
        else:
            zone = BIOMES["lake"]

        print("Casting line...")
        time.sleep(1.5)
        
        # THE CASINO ROLL (Indented 8 spaces)
        if random.random() < catch_chance:
            random_fish = random.choice(fish_types)
            max_weight = player_level * 20
            weight = random.randint(1, max_weight)
            size = random.randint(2, 26)
            
            print("\nyou got a...")
            print(f"{random_fish}")
            print(f"weight: {weight} kg | Size: {size} inches")
            
            catch_details = f"{random_fish} ({weight} kg | {size} inches)"
            inv.append(catch_details)
            
            # Silent backend disk logging (Indented 12 spaces)
            with open("fishing_log.txt", "a", encoding="utf-8") as log_file:
                log_file.write(f"{catch_details}\n")
            
            # Incremental level-up processing
            total_catches += 1
            if (1 + (total_catches // 5)) > player_level:
                player_level = 1 + (total_catches // 5)
                print(f"\nLEVEL UP! You are now level {player_level}!!")
                
        else: # Lined up perfectly with your catch_chance check!
            print("Ah! It snapped the line! The fish got away sadly.")


    elif action == "biome":
        # 1. Figure out what biome the player is currently qualified for
        if player_level >= 100:
            current_zone = BIOMES["volcano"]
        elif player_level >= 35:
            current_zone = BIOMES["woods"]
        elif player_level >= 25:
            current_zone = BIOMES["sea"]
        else:
            current_zone = BIOMES["lake"]
            
        # 2. Print out the full biome dossier
        print("\n=========================================")
        print(f"       ACTIVE CURRENT ENVIRONMENT        ")
        print("=========================================")
        print(current_zone["icon"]) # Displays the full ASCII badge!
        print(f"\n-> Biome Name: {current_zone['name']}")
        print(f"-> Base Reward: +{current_zone['exp']} EXP per catch")
        print(f"-> Weight Floor: {current_zone['min_weight']} kg")
        print("=========================================")

