Hello!! :3
so what this code does(scriptfishing.py) it like makes a log in the backend and also:
the frontend(the text) like yea u already know
made by jobr0 or vo1dbr0 or jobr0R3AL!! :D
