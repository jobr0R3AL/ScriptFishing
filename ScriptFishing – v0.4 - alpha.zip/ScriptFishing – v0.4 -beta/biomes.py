# biomes.py - The Modular ASCII Database

BIOMES = {
    "lake": {
        "name": "LOCAL TERMINAL LAKE",
        "icon": r"""
     _/\_/\_/\_
   =(   FISH   )=  [ BIOME 1: FRESHWATER ]
     ~\_/\_/\_/~   -----------------------""",
        "pool": ["Trout!", "Bass!", "Rainbow Trout!", "Salmon!", "Pike!", "Carp!"],
        "exp": 1,
        "min_weight": 1,
        "max_weight_multiplier": 20
    },
    
    "sea": {
        "name": "LOCAL TERMINAL SEA",
        "icon": r"""
     _ _ . . _ _
   =(   WHALE   )= [ BIOME 2: COASTAL SALT ]
     ~\_ _ . . _/~  ------------------------""",
        "pool": ["Pocket Whale", "Sturgeon!", "Walleye!", "Catfish!", "Goldfish?!"],
        "exp": 5,
        "min_weight": 10,
        "max_weight_multiplier": 35
    },
    
    "woods": {
        "name": "AUTUMN MIST WOODS",
        "icon": r"""
       /  \  /  \
      / /\ \/ /\ \ [ BIOME 3: FOREST STREAM ]
     /_/__\_/__/_\ -------------------------""",
        "pool": ["Mossy Perch!", "Woodland Salmon!", "Leaf-Trout!", "87kg Boot!"],
        "exp": 15,
        "min_weight": 5,
        "max_weight_multiplier": 45
    },
    
    "volcano": {
        "name": "THE DIAMOND VOLCANO",
        "icon": r"""
       /\      /\
      /  \/\/\/  \ [ ELITE ENDGAME BIOME ]
     /____\____/__\ ----------------------""",
        "pool": ["Magma Whitefish!", "Lava Trout!", "Obsidian Carp!", "DIAMOND SQUID!!!"],
        "exp": 500,
        "min_weight": 2568,
        "max_weight_multiplier": 100
    }
}

